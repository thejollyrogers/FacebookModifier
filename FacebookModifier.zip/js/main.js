// JavaScript Document

alert("test");
alert("sup");